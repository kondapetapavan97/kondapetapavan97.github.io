package DAO1;

import model.Amenities;

public interface AmenitiesDAO {
	public void addAmenities(Amenities Amenities);
	public Amenities getamenities(int cont_id);
	public void updateamenities(Amenities amenities);
	
}
